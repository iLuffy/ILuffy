task default -depends test

task test {
    Execute-ModuleAFunction
}